## OctaviOS v4.2 Thirteen Patches for Generic System Image
Patches for building OctaviOS v4.2 Thirteen

### How to apply patches? ###
```bash
git clone https://github.com/Hirozuto/gsi-patches -b octavi-thirteen
bash gsi-patches/apply.sh
```

## Credits
These people have helped this project in some way or another, so they should be the ones who receive all the credit:
- [OctaviOS Team](https://github.com/Octavi-Staging)
- [Nazim](https://github.com/naz664)
- [Attila](https://github.com/TheAttila)
- [Phhusson](https://github.com/phhusson)
- [AndyYan](https://github.com/AndyCGYan)
- [Ponces](https://github.com/ponces)
- [Yilliee](https://github.com/Yilliee)
- [ChonDoit](https://github.com/ChonDoit)
- [Iceows](https://github.com/Iceows)
